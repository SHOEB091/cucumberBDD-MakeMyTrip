package cucumberOptions;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/resources/features", 
    glue = { "stepDefinitions", "hooks" }, 
    plugin = { 
        "pretty",
        "html:target/cucumber-reports/report.html",
        "html:target/ExtentReport/SparkReport.html",
        "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
    }, 
    monochrome = true
)
public class TestRunnerTest {
	
}