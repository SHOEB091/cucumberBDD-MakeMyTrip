package stepDefinitions;
 
import io.cucumber.java.en.*;
import hooks.Hooks;
import pageObjects.*;
 
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.apache.commons.io.FileUtils;
 
import java.io.File;
import java.io.IOException;
 
public class TravelSteps {
 
	HomePage home = new HomePage(Hooks.driver, Hooks.wait);
	CabPage cabs = new CabPage(Hooks.driver);
	GiftCardPage gift = new GiftCardPage(Hooks.driver, Hooks.wait);
	HotelPage hotel = new HotelPage(Hooks.driver, Hooks.wait);
 
	// --- Background & Common Steps ---
 
	@Given("User is on MakeMyTrip Home Page")
	public void user_is_on_home() {
		Hooks.driver.get("https://www.makemytrip.com/");
		home.handlePopups();
	}
 
	@Then("User takes a screenshot")
	public void take_final_screenshot() {
		takeScreenshot("Final_Output");
	}
 
	// --- Cab Scenario Steps ---
 
	@When("User navigates to Cabs page")
	public void user_navigates_to_cabs_page() {
		cabs.clickCabs();
	}
 
	@When("User enters {string} as From location and {string} as To location")
	public void user_enters_locations(String from, String to) throws InterruptedException {
		cabs.enterCities(from, to);
	}
 
	@When("User selects departure date {string} {string}")
	public void user_selects_departure_date(String month, String year) {
		cabs.selectDate(month, year);
	}
 
	@When("User selects pickup time {string} and clicks Apply")
	public void user_selects_pickup_time(String time) {
		//cabs.selectTime(time);
		
	}
 
	@When("User clicks Search")
	public void user_clicks_search() {
       // cabs.applybtn();
		cabs.clickSearch();
	}
 
	@Then("User should see available cab options")
	public void user_should_see_available_cab_options() {
		// Select SUV car type from the filter sidebar
		cabs.selectSUV();
 
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
 
	@Then("The lowest cab price should be displayed")
	public void the_lowest_cab_price_should_be_displayed() {
		int price = cabs.getLowestPrice();
		System.out.println("Lowest Cab Price found: " + price);
	}
 
	@And("User returns to Home Page")
	public void user_returns_to_home_page() throws InterruptedException {
		
		Hooks.driver.get("https://www.makemytrip.com/");
 
		// Explicitly wait for the home page container to be visible
		Hooks.wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("landingContainer")));
		home.handlePopups();
		home.tap();
	}
	// --- Gift Card Scenario Steps ---
 
	@When("User selects Gift Cards and switches to the new tab")
	public void user_selects_gift_cards() throws InterruptedException {
 
		gift.clickGiftCards();
		gift.switchToNewTab();
	}
 
	@And("User selects the Wedding Gift Card")
	public void user_selects_wedding_card() throws InterruptedException {
		gift.clickWeddingCard();
	}
 
	@And("User enters sender details {string}, {string}, {string}")
	public void user_enters_sender_details(String name, String mobile, String email) throws InterruptedException {
		gift.setName(name);
		gift.setNumber(mobile);
		gift.setEmail(email);
	}
 
	@Then("User clicks Buy Now and captures a screenshot")
	public void user_clicks_buy_now_and_captures_screenshot() throws InterruptedException {
		gift.clickBuyNow();
		Thread.sleep(2000);
		gift.captureScreenshot();
	}
 
	@And("User checks maximum adult capacity in Hotels")
	public void hotel_logic() throws InterruptedException {
		// Return to main window if needed
		//here homeId is single string var, storing id of homepage tab
		if (Hooks.homeId != null) {
			Hooks.driver.switchTo().window(Hooks.homeId);
		}
		home.goToMenu("Hotels");
		System.out.println("Max Guest Limit Message: " + hotel.getMaxGuestLimit());
	}
 
	// --- Helper Method ---
	public void takeScreenshot(String fileName) {
		try {
			File src = ((TakesScreenshot) Hooks.driver).getScreenshotAs(OutputType.FILE);
			File dest = new File(System.getProperty("user.dir") + "/target/" + fileName + ".png");
			if (dest.getParentFile() != null)
				dest.getParentFile().mkdirs();
			FileUtils.copyFile(src, dest);
			System.out.println("Screenshot saved: " + dest.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}