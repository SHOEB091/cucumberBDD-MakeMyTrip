package pageObjects;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
//import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GiftCardPage extends BaseDriver {
//	WebDriver wait2 = new WebDriverWait(driver,Duration.ofSeconds(4));
	public GiftCardPage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
		PageFactory.initElements(driver, this);
	}
	WebDriverWait wait_2 = new WebDriverWait(driver,Duration.ofSeconds(1));
	WebDriverWait wait_3 = new WebDriverWait(driver,Duration.ofSeconds(3));

	
	@FindBy(xpath="//img[@alt='minimize']")
	WebElement mini;
	
	@FindBy(xpath = "//span[text()='Gift Cards']")
	WebElement giftCardLink;

	@FindBy(xpath = "//div[@class='all__card__wrap']/ul/li[1]/div")
	WebElement weddingCard;

	@FindBy(xpath = "//div[@class='deliver__content']")
	WebElement userinput;

	@FindBy(xpath = "//input[@name='senderName']")
	WebElement senderNameInput;

	@FindBy(xpath = "//input[@name='senderMobileNo']")
	WebElement senderPhoneInput;

	@FindBy(xpath = "//input[@name='senderEmailId']")
	WebElement senderEmailInput;

	@FindBy(xpath = "//button[@data-cy='BookingDetails_440']")
	WebElement buyNowBtn;

	public void clickGiftCards() throws InterruptedException {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 250)");
		wait_2.until(ExpectedConditions.elementToBeClickable(giftCardLink)).click();
	}

	//New Tab Open, webdriver will switch
	public void switchToNewTab() {
		for (String handle : driver.getWindowHandles()) {
			driver.switchTo().window(handle);
		}
	}

	public void clickWeddingCard() throws InterruptedException {
		// Scroll slightly to ensure visibility
		wait_2.until(ExpectedConditions.elementToBeClickable(mini)).click();
//		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//scrollby is used to scroll the windows using pixels
		js.executeScript("window.scrollBy(0, 150)");

		wait.until(ExpectedConditions.elementToBeClickable(weddingCard)).click();
	}

	public void setName(String name) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//intoview is used to scroll to locate the webelement where it is present
		js.executeScript("arguments[0].scrollIntoView(true);", userinput); // Scroll down to form
		Thread.sleep(2000);
		wait_3.until(ExpectedConditions.visibilityOf(senderNameInput));
		senderNameInput.clear();
		senderNameInput.sendKeys(name);
	}

	public void setNumber(String phnnumber) {
		wait_3.until(ExpectedConditions.visibilityOf(senderPhoneInput));
		senderPhoneInput.clear();
		senderPhoneInput.sendKeys(phnnumber);
	}

	public void setEmail(String email) {
		wait_3.until(ExpectedConditions.visibilityOf(senderEmailInput));
		senderEmailInput.clear();
		senderEmailInput.sendKeys(email);
	}

	public void clickBuyNow() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", buyNowBtn);
	}

	public void captureScreenshot() {
		try {
			TakesScreenshot ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			File dest = new File(System.getProperty("user.dir") + "/target/GiftCard_Output.png");

			if (dest.getParentFile() != null)
				//make directory or folder
				dest.getParentFile().mkdirs();

			FileUtils.copyFile(src, dest);
			System.out.println("Gift Card Screenshot saved: " + dest.getAbsolutePath());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}