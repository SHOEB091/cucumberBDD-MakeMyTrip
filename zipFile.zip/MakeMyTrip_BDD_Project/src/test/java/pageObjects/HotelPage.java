package pageObjects;

import org.openqa.selenium.*;

import org.openqa.selenium.support.ui.ExpectedConditions;

public class HotelPage extends BaseDriver {
//	@FindBy(xpath="//*[@data-cy='guestLabel']");
//	WebElement guestBtn = driver.findElement(By.xpath("//*[@data-cy='guestLabel']"));
	public HotelPage(WebDriver driver, org.openqa.selenium.support.ui.WebDriverWait wait) {
		super(driver, wait);
	}

	public String getMaxGuestLimit() throws InterruptedException {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[@for='guest']"))).click();
		Thread.sleep(2000);

		WebElement addBtn = driver.findElement(By.xpath("//div[@class='rmsGst']/div[1]/div[2]/div[2]/button[2]"));

		while (addBtn.isEnabled()) {
			addBtn.click();
		}

		return driver.findElement(By.xpath("//div[@class='rmsGst']/div[1]/div[2]/div[2]/span")).getText();
	}
}