package pageObjects;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends BaseDriver {
	
	public HomePage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
		PageFactory.initElements(driver, this);
	}
	WebDriverWait wait1 = new WebDriverWait(driver,Duration.ofSeconds(2));

	/*
		
	Exceptions:
		
	StaleElementReferenceException : For Delhi
	TimeOutException : for less wait time 3 secs
	NoSuchElementException : for wrong xpaths
	Element_Click_Intercepted_Exception : without coachmark black screen click, it tried to go down, to click gift button.
	
	*/
	
	@FindBy(xpath="//img[@alt='minimize']")
	WebElement mini;
	

    @FindBy(xpath = "//span[contains(@class,'chCabs')]")
    WebElement cabsTab;

    @FindBy(xpath = "//div[@class='flightSearchWidget']//span[contains(@class,'coachmark')]")
    WebElement coachmarkInWidget;

    // This matches the overlay coachmark (dismissable overlay)
    @FindBy(css = "span.coachmark")
     List<WebElement> coachmarkOverlays;

    @FindBy(className = "commonModal__close")
    WebElement commonModalCloseBtn;

    @FindBy(xpath = "//div/img[@alt='minimize']")
     WebElement minimizeImg;

    // --- Actions / Methods ---

    public void goToCabs() {
        try {
            wait1.until(ExpectedConditions.elementToBeClickable(cabsTab)).click();
        } catch (Exception ignored) {}
    }

    /**
     * Tries to click coachmark inside widget, then dismiss overlay if visible.
     */
    public void tap() {
    	
    	/*
        try {
            wait1.until(ExpectedConditions.elementToBeClickable(coachmarkInWidget)).click();
        } catch (Exception ignored) {}
       */
    	
        // dismiss overlay if present
        try {
            if (coachmarkOverlays != null && !coachmarkOverlays.isEmpty()) {
                WebElement overlay = coachmarkOverlays.get(0);
                if (overlay.isDisplayed()) {
                    overlay.click();
                }
            }
        } catch (Exception ignored) {}
    }

    /**
     * Handles common popups safely.
     */
    public void handlePopups() {
        // Close modal
        try {
            wait1.until(ExpectedConditions.visibilityOf(commonModalCloseBtn)).click();
        } catch (Exception ignored) {}
        
        try {
            if (minimizeImg.isDisplayed()) {
                minimizeImg.click();
            }
        } catch (Exception ignored) {}
    }

    /**
     * Goes to a menu dynamically (when menu name varies).
     * Since @FindBy cannot be dynamic, we keep By-based lookup ONLY here.
     */
    public void goToMenu(String menuName) {
        try {
            driver.findElement(By.xpath("//span[contains(@class,'ch" + menuName + "')]")).click();
        } catch (NoSuchElementException e) {
            driver.findElement(By.xpath("//span[text()='" + menuName + "']")).click();
        }
    }

	
	
	
}