package pageObjects;
 
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import java.util.List;
 
public class CabPage {
	WebDriver driver;
	WebDriverWait wait;
	JavascriptExecutor js;
 
	public CabPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
	}
	
	//FROM HOME-->CABS
	
	@FindBy(className = "commonModal__close")
	WebElement closePopup;
	
	@FindBy(xpath = "//img[@alt='minimize']")
	WebElement minimizeFloat;
	
	@FindBy(xpath = "//span[contains(@class,'chCabs')]")
	WebElement cabsTab;
	
	@FindBy(css = "#fromCity")
	WebElement fromCity;
	
	@FindBy(xpath = "//input[@autocomplete='off' and @title='From']")
	WebElement searchDelhi;
	
	
	@FindBy(xpath = "//*[ (text() = 'Delhi')]")
	WebElement clickDelhi;
	
	
	@FindBy(xpath = "//label[@for='toCity']/parent::div")
	WebElement toCity;
	
	@FindBy(xpath = "//input[@autocomplete='off' and @title='To']")
	WebElement searchManali;
	
	@FindBy(xpath = "//li[@role='option']/div")
	WebElement clickManali;
	
	@FindBy(id = "departure")
	WebElement departure;
	
	@FindBy(xpath = "//div[@class='DayPicker-Caption']")
	WebElement monthCaption;
	
	@FindBy(xpath = "//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")
	WebElement nextMonthBtn;
	
	@FindBy(xpath = "//label[@for='pickupTime']")
	WebElement pickupTime;
 
	@FindBy(xpath = "//div[@class='applyBtn']//span")
	WebElement applyBtn2;
	
//	@FindBy(className = "hrSlotItemChild")
//	List<WebElement> hourSlots;
	
	@FindBy(xpath = "//span[text()='APPLY']")
	WebElement applyBtn;
	
	@FindBy(xpath = "//p[@data-cy = 'onewaySearch']/a")
	WebElement searchBtn;
	
	@FindBy(xpath = "//div[@class='filterSection_contentWrapper___IFFB']//div[3][@role='checkbox']")
	WebElement suvCheckbox;
	
	// Locator from projectdemo for price calculation
	@FindBy(css = "span[class='cabDetailsCard_price__SHN6W']")
	List<WebElement> priceElements;
 
	// --- Actions ---
 
	public void handlePopups() {
		
		//by using explicit waits,it checks if element is visible, then it closes popup, else no popup found
		//login popup
		try {
			wait.until(ExpectedConditions.visibilityOf(closePopup)).click();
		} catch (Exception e) {
			System.out.println("No Modal Popup found");
		}
        // AI popup
		try {
			wait.until(ExpectedConditions.visibilityOf(minimizeFloat)).click();
		} catch (Exception e) {
			System.out.println("No Floating Popup found");
		}
	}
 
	public void clickCabs() {
		cabsTab.click();
	}
 
	public void enterCities(String from, String to) throws InterruptedException {
		
		fromCity.click();
		
		searchDelhi.sendKeys("delhi");
		
		clickDelhi.click();
		
		Thread.sleep(2000);
		
		toCity.click();
		
		Thread.sleep(2000);
		
		searchManali.sendKeys("manali");
		
		Thread.sleep(2000);
		
		clickManali.click();
	}
 
	public void selectDate(String targetMonth, String targetYear) {
		Actions action = new Actions(driver);
		action.moveToElement(departure).click().perform();
 
		while (true) {
			//firstly we stored month and year in a string
			
			String monthAndYear = wait.until(ExpectedConditions.visibilityOf(monthCaption)).getText();
			//used string array to split month and year
			String[] my = monthAndYear.split(" ");
			
			if (my[0].equalsIgnoreCase(targetMonth) && my[1].equals(targetYear)) {
				break;
			}
			//it clicks next button
			nextMonthBtn.click();
		}
		driver.findElement(By.xpath("//div[contains(@aria-label, 'Jun 10 2026')]")).click();
	}
 

 
	public void applybtn() {
		applyBtn.click();
	}
 
	public void clickSearch() {
		searchBtn.click();
	}
 
	public void selectSUV() {
		try {
			Actions actions = new Actions(driver);
			actions.moveToElement(suvCheckbox).click().perform();
			System.out.println("SUV filter applied successfully.");
		} catch (Exception e) {
			System.out.println("Could not click SUV filter: " + e.getMessage());
		}
	}
 
	public int getLowestPrice() {
		wait.until(ExpectedConditions.visibilityOfAllElements(priceElements));
		int minPrice = Integer.MAX_VALUE;
 
		for (WebElement priceElement : priceElements) {
			String priceText = priceElement.getText().replaceAll("[^0-9]", "");
			if (!priceText.isEmpty()) {
				int price = Integer.parseInt(priceText);
				if (price < minPrice) {
					minPrice = price;
				}
			}
		}
		return minPrice;
	}
}